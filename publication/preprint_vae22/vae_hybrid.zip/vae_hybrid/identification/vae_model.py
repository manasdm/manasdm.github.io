import torch
import torch.nn as nn





class EncoderPWAARX(nn.Module):
    """ This class implements a NN classifier model for PWA-ARX models
    Inputs:  Regressors;  {y[k-1], ..y[k-n_a], u[k-1], ... ,u[k-n_b]} torch.Size: (N, n_a+n_b ) 
    
    Outputs: Probability of each mode Y_class  torch.Size(N, n_modes)
             Mode sequence S_class {S[0], ..S[N-1]}     torch.Size(N, 1)
    
    Attributes
    ----------
    n_a: int number of autoregresive  lags in y
    n_b: int number of autoregressive lags in u
    n_modes: int number of classes/modes
    n_feat: number of hidden layer
    
    Inputs: regressors 
    """  
    def __init__(self, n_a,n_b, n_modes, n_feat = 8):
        super(EncoderPWAARX, self).__init__()
        self.n_a = n_a
        self.n_b = n_b
        self.n_modes = n_modes
        self.n_feat = n_feat
        self.net_class = nn.Sequential(
                nn.Linear(n_a+n_b, n_feat), # n_a+n_b regressors
                nn.ReLU(),
                nn.Linear(n_feat, n_modes),
                nn.Softmax(dim = 1)
                )
    def forward(self, phi):
        # phi : Tensor.Size (N, n_a+n_b)
        Y_class = self.net_class(phi)   # Y  shape (N,nmodes)
        S_class = torch.argmax(Y_class,1)
        S_class = torch.reshape(S_class,(-1,1))
        #self.S = S
        return Y_class, S_class
            
    
    

    
    
class DecoderPWAARX(nn.Module):
    """ This class implements decoder for PWA-ARX neural model with 3 modes 
    
     Inputs: Regressor and mode probabilities at time k
             {y[k-1], ..y[k-n_a], u[k-1], ... ,u[k-n_b], Y_class[k]} torch.Size(N, n_a+n_b+n_modes)
     Output: y[k]  Predicted output   torch.Size(N,1) (wighted avegerge of layers)

     Attributes
     ----------
     n_a : int.
           number of autoregressive lags in y
     n_b : int.
           number of autoregressive lags in u
     n_modes: int.
           number of modes 
     n_feat : int.
           number of units in the hidden layer
          
     """
    def __init__(self, n_a, n_b,  n_modes):
        super(DecoderPWAARX, self).__init__()
        self.n_a = n_a
        self.n_b = n_b
        self.n_modes = n_modes
        #self.n_feat = n_feat
        
        self.net = nn.ModuleList([nn.Linear(n_a+n_b+1, 1) for i in range(n_modes)])
        



    def forward(self, phi, Y_class):
        
        
        # phi : Tensor.Size (N, n_a+n_b)
        # Y_class = self.net_class(phi)   # Y  shape (N,n_modes)
        
        N = phi.shape[0]
        

        
        Y_pred = torch.zeros(N,1)
        
        
        for i in range(self.n_modes):
              
              phi_net = torch.cat((phi, Y_class[:,i].reshape(-1,1)), 1)
              Y_net   = self.net[i](phi_net)
              Y_pred  += Y_net*(Y_class[:,i].reshape(-1,1)) 
        

        
        return  Y_pred 
  
      
  
      
class EncoderPWA(nn.Module):
      """ This class implements a NN classifier model for PWA models
      Inputs:  Regressors;   torch.Size: (N, n_x) 
      
      Outputs: Probability of each mode Y_class  torch.Size(N, n_modes)
               Mode sequence S_class {S[0], ..S[N-1]}     torch.Size(N, 1)
      
      Attributes
      ----------
      n_x: int number of input features
      n_modes: int number of classes/modes
      n_feat: number of hidden layer
      
      Inputs: regressors 
      """  
      def __init__(self, n_x, n_modes, n_feat = 8):
          super(EncoderPWA, self).__init__()
          self.n_x = n_x
          self.n_modes = n_modes
          self.n_feat = n_feat
          self.net_class = nn.Sequential(
                  nn.Linear(n_x, n_feat), # n_a+n_b regressors
                  #nn.ReLU(),
                  nn.Linear(n_feat, n_modes),
                  nn.Softmax(dim = 1)
                  )
      def forward(self, phi):
          # phi : Tensor.Size (N, n_a+n_b)
          Y_class = self.net_class(phi)   # Y  shape (N,nmodes)
          S_class = torch.argmax(Y_class,1)
          S_class = torch.reshape(S_class,(-1,1))
          #self.S = S
          return Y_class, S_class
  
      
  
class DecoderPWA(nn.Module):
    """ This class implements decoder for PWA IO neural model
    
     Inputs: Regressor and mode probabilities at time k
             {X[k], Y_class[k]} torch.Size(N, n_x+n_modes)
     Output: y[k]  Predicted output   torch.Size(N,1) (wighted avegerge of linear layers)

     Attributes
     ----------
     n_x : int.
           number of input features 

     n_modes: int.
           number of modes 
     n_feat : int.
           number of units in the hidden layer
          
     """
    def __init__(self, n_x,  n_modes):
        super(DecoderPWA, self).__init__()
        self.n_x = n_x
        self.n_modes = n_modes
        #self.n_feat = n_feat
        
        self.net = nn.ModuleList([nn.Linear(n_x+1, 1) for i in range(n_modes)])

        


    def forward(self, phi, Y_class):
        
        
        # phi : Tensor.Size (N, n_a+n_b)
        # Y_class = self.net_class(phi)   # Y  shape (N,n_modes)
        

        
       N = phi.shape[0]
       

       
       Y_pred = torch.zeros(N,1)
       
       
       for i in range(self.n_modes):
             
             phi_net = torch.cat((phi, Y_class[:,i].reshape(-1,1)), 1)
             Y_net   = self.net[i](phi_net)
             Y_pred  += Y_net*(Y_class[:,i].reshape(-1,1))  
        
       return  Y_pred 
 
      
 
      
class DecoderPWNL(nn.Module):
     """ This class implements decoder for PW-NL IO neural model
     
      Inputs: Regressor and mode probabilities at time k
              {X[k], Y_class[k]} torch.Size(N, n_x+n_modes)
      Output: y[k]  Predicted output   torch.Size(N,1) (wighted avegerge of linear layers)

      Attributes
      ----------
      n_x : int.
            number of input features 

      n_modes: int.
            number of modes 
      n_feat : int.
            number of units in the hidden layer
           
      """
     def __init__(self, n_x,  n_modes, n_feat):
         super(DecoderPWNL, self).__init__()
         self.n_x = n_x
         self.n_modes = n_modes
         self.n_feat = n_feat
         
         self.net = nn.ModuleList([nn.Sequential(
                 nn.Linear(n_x+1, n_feat), # n_a+n_b regressors
                 nn.ReLU(),
                 nn.Linear(n_feat, 1)) for i in range(n_modes)])

         


     def forward(self, phi, Y_class):
         
         
         # phi : Tensor.Size (N, n_a+n_b)
         # Y_class = self.net_class(phi)   # Y  shape (N,n_modes)
         

         
        N = phi.shape[0]
        

        
        Y_pred = torch.zeros(N,1)
        
        
        for i in range(self.n_modes):
              
              phi_net = torch.cat((phi, Y_class[:,i].reshape(-1,1)), 1)
              Y_net   = self.net[i](phi_net)
              Y_pred  += Y_net*(Y_class[:,i].reshape(-1,1))  
         
        return  Y_pred 
    
    


        
    
