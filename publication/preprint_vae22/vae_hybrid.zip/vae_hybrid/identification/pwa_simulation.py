import torch
import numpy as np


class pwaSimulator:
    """ This class implements one step ahead prediction/simulation methods for the PWA
        and PWA-ARX model 

     Attributes
     ----------
     io_model: nn.Module
               The autoencoder model to be fitted
     
     io_classifier: nn.Module
               The encoder classifier to be fitted
     """

    def __init__(self, io_model, io_classifier):
        self.io_model = io_model
        self.io_classifier = io_classifier
        
        


    
    def f_onestep_PWAARX(self,PHI):
        """ One-step prediction for PWA-ARX model given the mode sequence
        
        Parameters
        ----------
        
        PHI: Tensor.Size: (N, n_a+n_b) 
        Y_class: Tensor.Size(N, n_modes)
        S  : Tensor.Size: (N,1)             # Mode sequence
        
        Returns
        ---------
        Y_pred: Tensor.Size:(N,n_y)
                One-step ahead predicted output
        
        """
        
        Y_class, S_class = self.io_classifier(PHI)
        Y_pred  = self.io_model(PHI, Y_class)
        return  Y_pred, Y_class, S_class 
  
      
  
      
    def f_onestep_PWA(self,PHI):
        """ One-step prediction for PWA models given the mode sequence
        
        Parameters
        ----------
        
        PHI: Tensor.Size: (N, n_x) 
        Y_class: Tensor.Size(N, n_modes)
        S  : Tensor.Size: (N,1)             # Mode sequence
        
        Returns
        ---------
        Y_pred: Tensor.Size:(N,n_y)
                One-step ahead predicted output
        
        """
        
        Y_class, S_class = self.io_classifier(PHI)
        Y_pred  = self.io_model(PHI, Y_class)
        return  Y_pred, Y_class, S_class 
    
    
    
    


    
    
    
    
    
    def f_sim_PWAARX(self, y_seq, u_seq, U):
        """ Open-loop simulation
        
        Parameters
        -----------
        y_seq: Tensor.Size: (n_a) Initial regressor with past values of y
        u_seq: Tensor.Size: (n_b) Initial regressor with past values of u
        
        U : Tensor. Size: (N, n_u)
            Input sequence tensor
            

            
        Returns
        -------
        
        Ysim: Tensor. Size: (N, n_y)
              Open-loop simulation of the output
        """
        N = np.shape(U)[0]
        Y_list = []
        for i in range(N):
            phi = torch.cat((y_seq, u_seq))
            phi = torch.reshape(phi, (1,-1))

            
            y_c, s = self.io_classifier(phi)
            yi     = self.io_model(phi, y_c)
            
           
            Y_list += [yi[0]]
            
            if i<N-1:
                # y shift
                y_seq[1:] = y_seq[0:-1]
                y_seq[0]  = yi
                
                # u shift
                u_seq[1:] = u_seq[0:-1]
                u_seq[0]  = U[i]
        
        Y = torch.stack(Y_list, 0)
        return Y
            
        
                           
    
    
    
    


