# -*- coding: utf-8 -*-
"""
Created on Thu Mar 17 12:51:50 2022

@author: Manas Mejari

Identification of PWARX models with variational autoencoders.
"""

import torch 
import torch.nn as nn
import torch.optim as optim
import numpy as np
#import scipy.linalg
#from sklearn.cluster import KMeans
from sklearn.mixture import GaussianMixture

import matplotlib.pyplot as plt
import time
import sys
import os
#import identification

path = os.getcwd()
parent = os.path.join(path, os.pardir)

sys.path.append(os.path.abspath(parent))
#sys.path.append(os.path.join("..", '..'))



from identification.vae_model import EncoderPWAARX

from identification.vae_model import DecoderPWAARX

from identification.pwa_simulation import pwaSimulator




if __name__ == '__main__':
    
    np.random.seed(0)           # For reproducibility of the results
    torch.manual_seed(0)        # For reproducibility of the results
    
    # Overall parameters
    N = 6000                   # N training samples of data
    Nval = 2000                 # Nval validation samples
    
    # Model strucure
    n_a = 1                     # autoregressive coefficients for y
    n_b = 1                     # autoregressive coefficients for u
    n_modes = 3                 # Number of modes
    
    n_feat_class = 8            # number of hidden layer neuraons (Encoder)
    #n_feat_reg = 4              # number of hidden layer neurons (Decoder) for non-linear decoder
    
    # Optimization
    lam = 1e-3                  # Regularization hyperparameter between prior and posteiror
    
    lr = 1e-3                   # learning rate 
    num_iter = 20000            # gradient-based optimization steps
    test_freq = 100             # print message every test_freq iterations
               
    std_noise = 0.5              # AWGN Noise standard deviation
    err = std_noise*torch.randn(N,1)  # Gaussian noise 
    #err = std_noise*torch.rand(N,1)- (std_noise/2)
    

#%% --------------- Data gnerating system PWARX ----------------



    # Training dataset 

    u  = 8*torch.rand(N, 1)-4          # Random input signal training
    y  = torch.zeros(N,1)                # Initial output
    S  = torch.ones(N,1, dtype = int)    # Initial mode sequence

    
    for k in range(1,N):
        if (4*y[k-1,0]- u[k-1,0]+10<0):
            y[k,0] = -0.4*y[k-1,0]+u[k-1,0]+1.5 + err[k,0]
            S[k,0] = 0
        elif (4*y[k-1,0] - u[k-1,0]+10>=0 and 5*y[k-1,0]+u[k-1,0]-6<=0):
            y[k,0] = 0.5*y[k-1,0]-1*u[k-1,0]-0.5 + err[k,0]
            S[k,0] = 1   
        elif (5*y[k-1,0]+u[k-1,0]-6>0):
            y[k,0] = -0.3*y[k-1,0]+0.5*u[k-1,0]-1.7 + err[k,0]
            S[k,0] = 2
            
     
        
    # Signal-to-noise-ratio 
    P_sig    = (torch.mean((y-err)**2, 0)).item()
    P_noise = std_noise**2
    SNR     = P_sig/(P_noise+1e-10)
    SNR_db  = 10*np.log10(SNR)
    print("Signal-to-noise ratio (dB): %2.2f" % SNR_db)
    
    plt.close('all')
    fig, ax = plt.subplots(3,1,figsize=(5, 5))
    ax[0].plot(np.array(u), label= 'Input')
    ax[1].plot(np.array(y), label= 'Output')
    ax[2].hist(np.array(S), label = 'Mode sequence')
    
    
    
    

    
    
    
    # Validation data set Noise free
    
    uval  = 8*torch.rand(Nval, 1)-4            # Random input signal training
    yval  = torch.zeros(Nval,1)                # Initial output
    Sval  = torch.ones(Nval,1, dtype = int)    # Initial mode sequence
    
    for k in range(1,Nval):
        if (4*yval[k-1,0]- uval[k-1,0]+10<0):
            yval[k,0] = -0.4*yval[k-1,0]+uval[k-1,0]+1.5 
            Sval[k,0] = 0
        elif (4*yval[k-1,0] - uval[k-1,0]+10>=0 and 5*yval[k-1,0]+uval[k-1,0]-6<=0):
            yval[k,0] = 0.5*yval[k-1,0]-1*uval[k-1,0]-0.5 
            Sval[k,0] = 1    
        elif (5*yval[k-1,0]+uval[k-1,0]-6>0):
            yval[k,0] = -0.3*yval[k-1,0]+0.5*uval[k-1,0]-1.7 
            Sval[k,0] = 2
            
    
    
    
    
    
     ## Prepare data for neural PWA training
    n_max   = np.max((n_a, n_b))    # delay 
    phi     = np.zeros((N,n_a+n_b))
    phi_val = np.zeros((Nval,n_a+n_b))
    

        
        
    y1 = y.numpy()
    u1 = u.numpy()
        
    for k in range(n_max+1,N):
        y_temp = y1[k-1:k-n_a-1:-1].reshape(1,-1)
        u_temp = u1[k-1:k-n_b-1:-1].reshape(1,-1)
        phi[k,:] = np.concatenate((y_temp, u_temp), axis = 1)
        
        
    yv = yval.numpy()
    uv = uval.numpy()  
        
        
    for k in range(n_max+1,Nval):
        y_temp = yv[k-1:k-n_a-1:-1].reshape(1,-1)
        u_temp = uv[k-1:k-n_b-1:-1].reshape(1,-1)
        phi_val[k,:] = np.concatenate((y_temp, u_temp), axis = 1)
    
    
    

    
    phi_torch = torch.from_numpy(phi)
    phi_torch = phi_torch.to(torch.float32)
    
    phi_val_torch = torch.from_numpy(phi_val)
    phi_val_torch = phi_val_torch.to(torch.float32)
    
    x = np.sort(np.array(y),axis = 0)
    fig, ax = plt.subplots(1,1,figsize=(5, 5))
    ax.plot(x, 4*x+10, color = 'black')
    ax.plot(x, -5*x+6, color = 'black')
    ax.set_xlim(-4, 4)
    ax.set_ylim(-5, 5)
    for j in range(n_modes):
        ax.scatter(phi_torch[(S==j)[:,0]][:,0],phi_torch[(S==j)[:,0]][:,1], alpha=0.5)

    
    #%% K-means for prior probabilites
    #kmeans = KMeans(n_clusters=n_modes, random_state=0).fit(phi_torch)
    gm = GaussianMixture(n_components=n_modes, random_state=0).fit(phi_torch)
    prior_prob = gm.predict_proba(phi_torch)
    
    prior_prob = torch.from_numpy(prior_prob)
    prior_prob = prior_prob.to(torch.float32)

    #%% ------------ Build neural network model -----------------
    
    # Setup VAE model structure
    S_estimator     =  EncoderPWAARX(n_a=n_a, n_b=n_b, n_modes=n_modes, n_feat=n_feat_class)
    #pwa_io_model    =  SwitchIOModel(n_a=n_a, n_b=n_b, n_modes=n_modes, n_feat=n_feat_reg)
    pwa_io_model    =  DecoderPWAARX(n_a=n_a, n_b=n_b, n_modes=n_modes)
    
    pwa_io_solution =  pwaSimulator(pwa_io_model, S_estimator)
    
    
    
    params_reg   = list(pwa_io_solution.io_model.parameters())
    params_class = list(pwa_io_solution.io_classifier.parameters())
    
    
    
    
    # Setup optimizer
    #optimizer = optim.Adam(pwa_io_solution.io_model.parameters(), lr=lr)
    #optimizer = optim.Adam([{'params': params_reg,    'lr': lr}, {'params': params_class, 'lr': 1*lr}],  lr=lr)
    
    optimizer = optim.Adam(params_reg+params_class, lr = lr)
    
    loss_type = nn.MSELoss()
    
    
    LOSS = []
    start_time = time.time()
    
    #%% -------------Training loop  ------------------------------------ 
    
    for itr in range(1, num_iter+1):
        
        #print('\n Iter: {:04d}'.format(itr))
        optimizer.zero_grad()
        

        
        
        # Perform one-step ahead prediction
        Y_pred, Y_class, S_est = pwa_io_solution.f_onestep_PWAARX(phi_torch)
        
        
        
    
        
        # Regularization over active mode only 
        
        active_prob = torch.max(Y_class, axis = 1)[0]
        temp = active_prob*torch.log(active_prob)
        reg_loss = torch.mean(temp)
        
        
        
        
        fit_err = (Y_pred-y)**2
        
        
        
        

        
        loss = torch.mean(fit_err) + lam*reg_loss
        
        
        

        
        # Statistics
        LOSS.append(loss.item())
        if itr % test_freq == 0:
            print('Iter {:04d} | Total Loss {:.6f}'.format(itr, loss.item()))
            
            print('Iter {:04d} | Reg Loss {:.6f}'.format(itr, reg_loss.item()))
            

        
        
        
        # Backpropogate and optimize weights
        loss.backward()
        optimizer.step()
        
        #prior_prob = Y_class.detach()
    
    train_time = time.time() - start_time 
    print(f"\nTrain time: {train_time:.2f}")
    
    #%% Results 
    
    with torch.no_grad():
        

        
        y_pred_train, _, S_est_train = pwa_io_solution.f_onestep_PWAARX(phi_torch)


        
        err_train = y_pred_train - y                # one step ahead error
        loss_train =  torch.mean((err_train)**2)    # ideally  noise variance (0-mean)
        
        
        den = torch.mean((y - torch.mean(y))**2)
        BFR_train_one_step = 100*np.maximum(0, 1 - np.sqrt((loss_train.item())/(den.item())))
        
        # BFR_train_one_step Ideally: 1- (1+10^(SNR_db/10))^(-0.5)
        
        print("---------------------------------------")
        print(f"\n Best Fit Rate Train (one_step): {BFR_train_one_step:2.2f} %")
        
        R2_train = 100*(1- (loss_train.item())/(den.item()))
          
          
          
        print("---------------------------------------")
        print(f"\n R2 Train (one step prediction): {R2_train:2.2f} %")
        
        
        ## Validation
        
        # simulation error
        
        y_seq_val = yval[0:n_a,0]
        u_seq_val = uval[0:n_b,0]
        
        y_sim_val = pwa_io_solution.f_sim_PWAARX(y_seq_val, u_seq_val, uval)
        err_val = y_sim_val - yval
        loss_val =  torch.mean((err_val)**2)
        
        den = torch.mean((yval - torch.mean(yval))**2)
        BFR_val = 100*np.maximum(0, 1 - np.sqrt((loss_val.item())/(den.item())))
        
        
        
        print("---------------------------------------")
        print(f"\n Best Fit Rate Validation (simulation): {BFR_val:2.2f} %")
        
        R2_test_sim = 100*(1- (loss_val.item())/(den.item()))
          

          
        print("---------------------------------------")
        print(f"\n R2 Test (Simulation): {R2_test_sim:2.2f} %")
        
        
        # One step ahead prediction error 
        y_pred_val,Y_class_val, S_est_val = pwa_io_solution.f_onestep_PWAARX(phi_val_torch)
         
        err_test = y_pred_val - yval                # one step ahead error test
        loss_test =  torch.mean((err_test)**2)     # ideally  noise variance (0-mean)
        
        
        den = torch.mean((yval - torch.mean(yval))**2)
        BFR_test_one_step = 100*np.maximum(0, 1 - np.sqrt((loss_test.item())/(den.item())))
        
        # BFR_train_one_step Ideally: 1- (1+10^(SNR_db/10))^(-0.5)
        
        print("---------------------------------------")
        print(f"\n Best Fit Rate Test (one_step): {BFR_test_one_step:2.2f} %")
        
        R2_test = 100*(1- (loss_test.item())/(den.item()))
          
          
          
        print("---------------------------------------")
        print(f"\n R2 Test (one step prediction): {R2_test:2.2f} %")
        
        
        
        
        

        
        
        
        
        
        
        
        
    
       
    fig, ax = plt.subplots(1,1, figsize=(5,5))
    ax.plot(LOSS)
    ax.grid(True)
    ax.set_ylabel("Training Loss (-)")
    ax.set_xlabel("Iteration (-)")
    
    fig, ax = plt.subplots(1,1, figsize=(5, 5))
    ax.plot(y_pred_train[0:5000])
    ax.plot(y[0:5000])
    ax.grid(True)
    ax.set_ylabel("Training Output: One step prediction")
    ax.set_xlabel("Samples")
    
    fig, ax = plt.subplots(1,1, figsize=(5, 5))
    ax.plot(y_sim_val[0:500])
    ax.plot(yval[0:500])
    ax.grid(True)
    ax.set_ylabel("Validation Output: Simulation")
    ax.set_xlabel("Samples")
    
    
    fig, ax = plt.subplots(1,1, figsize=(5, 5))
    ax.plot(err_train[0:5000])
    ax.plot(err[0:5000])
    ax.grid(True)
    ax.set_ylabel("Error Train ")
    ax.set_xlabel("Samples")
    
    
    fig, ax = plt.subplots(1,1, figsize=(5, 5))
    ax.plot(err_val[0:2000])
    ax.grid(True)
    ax.set_ylabel("Error validation ")
    ax.set_xlabel("Samples")
    
    

    
    
    
    fig, ax = plt.subplots(1,1,figsize=(5, 5))
    ax.plot(x, 4*x+10, color = 'black')
    ax.plot(x, -5*x+6, color = 'black')
    ax.set_xlim(-4, 4)
    ax.set_ylim(-5, 5)  
    for j in range(n_modes):
        ax.scatter(phi_torch[(S_est_train==j)[:,0]][:,0],phi_torch[(S_est_train==j)[:,0]][:,1],   alpha=0.5)

    
    
    
    fig, ax = plt.subplots(1,1,figsize=(6, 6))
    
    fig.set_size_inches(w=7, h=5)
    plt.xticks(fontsize=20)
    plt.yticks(fontsize=20)
    ax.set_xlim(-5, 5)
    ax.set_ylim(-4, 4) 
    ax.set_xlabel(r'$y_{t-1}$', labelpad = 0.1, fontsize = 20)
    ax.set_ylabel(r'$u_{t-1}$', labelpad = 0.1, fontsize = 20)
    
    ax.plot(x, 4*x+10, color = 'black', linewidth = 2)
    ax.plot(x, -5*x+6, color = 'black', linewidth = 2)

    for j in range(n_modes):
        ax.scatter(phi_val_torch[(S_est_val==j)[:,0]][:,0],phi_val_torch[(S_est_val==j)[:,0]][:,1],   alpha=0.5)
    
    plt.tight_layout(pad=1)
    plt.savefig("figures/PWA_ARX_partition.pdf")
    
    #fig, ax = plt.subplots(1,1, figsize=(7.5, 6))
    #ax.plot(S_est[0:200], 'b--')
    #ax.plot(S_init[0:200], 'r--')
    #ax.grid(True)
    #ax.set_ylabel("Mode")
    #ax.set_xlabel("Samples")
        
    #print("----------Weights-------------")
    #print(pwa_io_model.net[0].weight)
    #print(pwa_io_model.net_class[2].weight)
    
    
    
    
    





