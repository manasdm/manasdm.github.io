# -*- coding: utf-8 -*-
"""
Created on Mon Sep 12 22:09:47 2022

@author: Manas Mejari

PWA regression example from Bemporad PARC
"""
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np 
import polytope

from sklearn.mixture import GaussianMixture
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
import sys
import os 
import time

path = os.getcwd()
parent = os.path.join(path, os.pardir)
sys.path.append(os.path.abspath(parent))

from identification.vae_model import EncoderPWA

from identification.vae_model import DecoderPWA

from identification.pwa_simulation import pwaSimulator

if __name__=='__main__':
      
      np.random.seed(0)             # For reproducibility
      torch.manual_seed(0)          # For reproducibility
      
      # Overall parameters
      N = 1000                        #  N samples of data
      test_size = 0.2                 #  Test samples percente
      N_train = int(N*(1-test_size))       #  No. of training samples
      
      
      
      # Model strucure
      n_x     = 2             # Number of input features 
      n_modes = 5             # Number of modes
      n_feat_class = 8        # number of hidden layer neuraons (Encoder)
      #n_feat_reg = 4         # number of hidden layer neurons (Decoder)
      
      
      # Optimization
      lam = 1e-4                  # Regularization hyperparameter between prior and posteiror
      
      lr = 1e-2                   # learning rate 
      num_iter = 20000             # gradient-based optimization steps
      test_freq = 100             # print message every test_freq iterations
                 
      std_noise = 0.0                  # AWGN Noise standard deviation
      err_x = std_noise*np.random.randn(N,n_x)  # Gaussian noise 
      err_y = std_noise*np.random.randn(N,1)  # Gaussian noise 
      
      
      
      xlim = 4
      xmin = np.array([-xlim,-xlim])
      xmax = np.array([xlim,xlim])

#%%   Data generating PWA system  
      
      X = np.random.rand(N, n_x) * np.array([xmax[0] - xmin[0], xmax[1] - xmin[1]]) + np.array([xmin[0], xmin[1]])
      Y  = torch.zeros(N,1)                # Initial output
      S  = torch.ones(N,1, dtype = int)    # Initial mode sequence
      
      


      Theta = np.array([[0.8031,0.0219,-0.3227],     # True parameter vector 
                        [0.0942,-0.5617,-0.1622],
                        [0.9462,-0.7299,-0.7141],
                        [-0.4799,0.1084,-0.1210],
                        [0.5770,0.1574,-0.1788]])
      
      for k in range(N):
            x1, x2 = X[k,:]
            
            Y[k,0] = np.max(np.array([Theta[0]@np.array([x1,x2,1]), 
                                      Theta[1]@np.array([x1,x2,1]),
                                      Theta[2]@np.array([x1,x2,1]),
                                      Theta[3]@np.array([x1,x2,1]),
                                      Theta[4]@np.array([x1,x2,1]),]))
                                      
            
            S[k,0] = np.argmax(np.array([Theta[0]@np.array([x1,x2,1]), 
                                         Theta[1]@np.array([x1,x2,1]),
                                         Theta[2]@np.array([x1,x2,1]),
                                         Theta[3]@np.array([x1,x2,1]),
                                         Theta[4]@np.array([x1,x2,1]),]))
                                         
            
      Y = Y + err_y
      X = X + err_x
      #%% Plot 
      
      omega = Theta[:,0:2]
      gamma = Theta[:,2]
      


      # Plot PWL partition
      A = np.vstack((np.eye(2), -np.eye(2), np.zeros((n_modes - 1, 2))))
      B = np.vstack((np.array([xmax[0], xmax[1], -xmin[0], -xmin[1]]).reshape(4, 1),
                     np.zeros((n_modes - 1, 1))))

      plt.close('all')
      fig, ax = plt.subplots(1,1, figsize=(5,5))
      #ax.grid(True)
      fig.set_size_inches(w=5, h=5)
      plt.xticks(fontsize=20)
      plt.yticks(fontsize=20)
      ax.set_xlim(-xlim, xlim)
      ax.set_ylim(-xlim, xlim)
      ax.set_xlabel(r'$x_1$', labelpad = 0.1, fontsize = 20)
      ax.set_ylabel(r'$x_2$', labelpad = 0.1, fontsize = 20)
      
      for j in range(0, n_modes):
          plt.scatter(X[(S==j)[:,0]][:,0],X[(S==j)[:,0]][:,1],   alpha=0.5)
          i = 4
          for h in range(0, n_modes):
              if h != j:
                  A[i, :] = omega[h, :] - omega[j, :]
                  B[i] = -gamma[h] + gamma[j]
                  i += 1
          P = polytope.Polytope(A, B)
          P.plot(ax=ax,color='w',alpha=1,linewidth=2)
      plt.tight_layout(pad=0.1)
      plt.savefig("figures/true_pwa.pdf")      
 #%% Train-test split     
      
      X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=test_size)
      

      
      #X_train = X_train + err_x
      #Y_train = Y_train + err_y
      
      
      phi_torch = torch.from_numpy(X_train)
      phi_torch = phi_torch.to(torch.float32)
      
      phi_val_torch = torch.from_numpy(X_test)
      phi_val_torch = phi_val_torch.to(torch.float32)
      
      
      #%% K-means for prior probabilites
      #kmeans = KMeans(n_clusters=n_modes, random_state=0).fit(phi_torch)
      gm = GaussianMixture(n_components=n_modes, random_state=0).fit(phi_torch)
      prior_prob = gm.predict_proba(phi_torch)
      
      prior_prob = torch.from_numpy(prior_prob)
      prior_prob = prior_prob.to(torch.float32)
      
      #%% ------------ Build neural network model -----------------
      
      # Setup neural model structure
      S_estimator     =  EncoderPWA(n_x=n_x, n_modes=n_modes, n_feat=n_feat_class)
      
      pwa_io_model    =  DecoderPWA(n_x=n_x, n_modes=n_modes) 
      
      pwa_io_solution =  pwaSimulator(pwa_io_model, S_estimator)
      
     
      
      params_reg   = list(pwa_io_solution.io_model.parameters())
      params_class = list(pwa_io_solution.io_classifier.parameters())
      
      
      
      
      # Setup optimizer
      #optimizer = optim.Adam(pwa_io_solution.io_model.parameters(), lr=lr)
      #optimizer = optim.Adam([{'params': params_reg,    'lr': lr}, {'params': params_class, 'lr': 1*lr}],  lr=lr)
      
      optimizer = optim.Adam(params_reg+params_class, lr = lr)
      
      loss_type = nn.MSELoss()
      
      
      LOSS = []
      start_time = time.time()
      
      
      #%% -------------Training loop  ------------------------------------ 
      
      for itr in range(1, num_iter+1):
          
          #print('\n Iter: {:04d}'.format(itr))
          optimizer.zero_grad()
                             
          # Perform one-step ahead prediction
          
          Y_pred, Y_class, S_est = pwa_io_solution.f_onestep_PWA(phi_torch)
          
          
          # Regulariation 
          

          

          # Regularization over active mode only 
          
          active_prob = torch.max(Y_class, axis = 1)[0]
          temp = 1.*active_prob*torch.log(active_prob)
          #temp = -1.*torch.log(active_prob)
          reg_loss = torch.mean(temp)
          
          # Mode collapse avoid entropy
          
          #time_avg_modes = torch.mean(Y_class, axis =0)
          #entropy_modes = time_avg_modes*torch.log(time_avg_modes)
          #entropy_loss = torch.sum(entropy_modes)
          
          
          
          
          
          fit_err = (Y_pred-Y_train)**2
          
          
          loss = torch.mean(fit_err) + lam*reg_loss #+ 1e-3*entropy_loss #+ lam*reg_loss #+ lam*entropy_loss
          
          
          
          # Statistics
          LOSS.append(loss.item())
          if itr % test_freq == 0:
              print('Iter {:04d} | Total Loss {:.6f}'.format(itr, loss.item()))
              
              print('Iter {:04d} | Reg Loss {:.6f}'.format(itr, reg_loss.item()))
              

          
          
          
          # Backpropogate and optimize weights
          loss.backward()
          optimizer.step()
          
          #prior_prob = Y_class.detach()
      
      train_time = time.time() - start_time 
      print(f"\nTrain time: {train_time:.2f}")
      
      
      
      #%% Results 
      
      with torch.no_grad():
          

          
          
          y_pred_train, _, S_est_train = pwa_io_solution.f_onestep_PWA(phi_torch)


          
          err_train = y_pred_train - Y_train                # one step ahead error
          loss_train =  torch.mean((err_train)**2)    # ideally  noise variance (0-mean)
          
          
          den = torch.mean((Y_train - torch.mean(Y_train))**2)
          BFR_train_one_step = 100*np.maximum(0, 1 - np.sqrt((loss_train.item())/(den.item())))
          
          R2_train = 100*(1- (loss_train.item())/(den.item()))
          
          # BFR_train_one_step Ideally: 1- (1+10^(SNR_db/10))^(-0.5)
          
          print("---------------------------------------")
          print(f"\n Best Fit Rate Train (one_step): {BFR_train_one_step:2.2f} %")
          
          print("---------------------------------------")
          print(f"\n R2 Train : {R2_train:2.2f} %")
          
          
          ## Test data
          
          y_pred_test, _, S_est_test = pwa_io_solution.f_onestep_PWA(phi_val_torch)
          


          
          err_test = y_pred_test- Y_test                # one step ahead error
          loss_test =  torch.mean((err_test)**2)    # ideally  noise variance (0-mean)
          
          
          den = torch.mean((Y_test - torch.mean(Y_test))**2)
          BFR_test_one_step = 100*np.maximum(0, 1 - np.sqrt((loss_test.item())/(den.item())))
          
          R2_test = 100*(1- (loss_test.item())/(den.item()))
          
          # BFR_train_one_step Ideally: 1- (1+10^(SNR_db/10))^(-0.5)
          
          print("---------------------------------------")
          print(f"\n Best Fit Rate Test (one_step): {BFR_test_one_step:2.2f} %")
          
          print("---------------------------------------")
          print(f"\n R2 Test : {R2_test:2.2f} %")
          
          
          Y_class, S_est = pwa_io_solution.io_classifier(phi_torch) 
          
          Y_class_val, S_est_val = pwa_io_solution.io_classifier(phi_val_torch) 
          

          
          
      fig, ax = plt.subplots(1,1, figsize=(3,3))
      ax.plot(LOSS)
      ax.grid(True)
      ax.set_ylabel("Training Loss (-)")
      ax.set_xlabel("Iteration (-)")
      

            

      fig, ax = plt.subplots(1,1)
      #ax.grid(True)
      fig.set_size_inches(w=5, h=5)
      ax.set_xlim(-xlim, xlim)
      ax.set_ylim(-xlim, xlim)
      plt.xticks(fontsize=20)
      plt.yticks(fontsize=20)
      ax.set_xlabel(r'$x_1$',  fontsize=20)
      ax.set_ylabel(r'$x_2$',  fontsize=20)
      #ax.set_aspect('equal', adjustable='box')
      plt.tight_layout(pad=0.1)
      

      for j in range(0, n_modes):
          ax.scatter(phi_torch[(S_est==j)[:,0]][:,0],phi_torch[(S_est==j)[:,0]][:,1],   alpha=0.5)
          i = 4
          for h in range(0, n_modes):
              if h != j:
                  A[i, :] = omega[h, :] - omega[j, :]
                  B[i] = -gamma[h] + gamma[j]
                  i += 1
          P = polytope.Polytope(A, B)
          P.plot(ax=ax,color='w',alpha=1,linewidth=2)

      plt.savefig("figures/estimated_pwa.pdf")    
          
          
      fig, ax = plt.subplots(1,1,figsize=(5, 5))
 
      for j in range(0, n_modes):
          ax.scatter(phi_val_torch[(S_est_val==j)[:,0]][:,0],phi_val_torch[(S_est_val==j)[:,0]][:,1],   alpha=0.5)
          i = 4
          for h in range(0, n_modes):
              if h != j:
                  A[i, :] = omega[h, :] - omega[j, :]
                  B[i] = -gamma[h] + gamma[j]
                  i += 1
          P = polytope.Polytope(A, B)
          P.plot(ax=ax,color='w',alpha=1,linewidth=2)
      
          
          

