# -*- coding: utf-8 -*-
"""
Created on Thu Mar 17 12:51:50 2022

@author: Manas Mejari

Identification of PWARX models with variational autoencoders
"""

import torch 
import torch.nn as nn
import torch.optim as optim
import numpy as np
#import scipy.linalg
#from sklearn.cluster import KMeans
from sklearn.mixture import GaussianMixture

import matplotlib.pyplot as plt
import time
import sys
import os
#import identification

path = os.getcwd()
parent = os.path.join(path, os.pardir)

sys.path.append(os.path.abspath(parent))
#sys.path.append(os.path.join("..", '..'))



from identification.vae_model import EncoderPWAARX

from identification.vae_model import DecoderPWNL

from identification.pwa_simulation import pwaSimulator




if __name__ == '__main__':
    
    np.random.seed(0)           # For reproducibility of the results
    torch.manual_seed(0)        # For reproducibility of the results
    
    # Overall parameters
    N = 6000                 # N training samples of data
    Nval =2000                # Nval validation samples
    
    # Model strucure
    n_x = 1                    # autoregressive coefficients for y
    #n_b = 1                     # autoregressive coefficients for u
    n_modes = 3                 # Number of modes
    
    n_feat_class = 16            # number of hidden layer neuraons (Encoder)
    n_feat_reg = 8              # number of hidden layer neurons (Decoder) for non-linear decoder
    
    # Optimization
    lam = 1e-2             # Regularization hyperparameter between prior and posteiror
    
    lr = 1e-3                   # learning rate 
    num_iter = 20000            # gradient-based optimization steps
    test_freq = 100             # print message every test_freq iterations
               
    std_noise = 0.3              # AWGN Noise standard deviation
    err = std_noise*torch.randn(N,1)  # Gaussian noise 
    #err = std_noise*torch.rand(N,1)- (std_noise/2)
    

#%% --------------- Data gnerating system PWNL ----------------



    # Training dataset 
    x_min = -15
    x_max = 20
                         

    x  = (x_max-x_min)*torch.rand(N, n_x) + x_min          # Random input signal training
    y  = torch.zeros(N,1)                # Initial output
    
    S  = torch.ones(N,1, dtype = int)    # Initial mode sequence
    reg1 = np.empty((1,2))
    reg2 = np.empty((1,2))
    reg3 = np.empty((1,2))
    
    for k in range(0,N):
        
        if (x[k,0]>0 and x[k,0] <= 10):
            y[k,0] = -1+ 0.01*x[k,0] + 1*(np.sin(x[k,0]))/x[k,0]+ err[k,0]
            S[k,0] = 1
            reg1 = np.concatenate((reg1, np.array([[y[k,0].item(), x[k,0].item()]])), axis = 0)
        elif (x[k,0]> 10 and x[k,0] <= 20):
            y[k,0] = 2 + 0.2*(np.exp(-0.5*(((x[k,0]-15)**2)/5))) + err[k,0]
            S[k,0] = 2
            reg2 = np.concatenate((reg2, np.array([[y[k,0].item(), x[k,0].item()]])), axis = 0)
        elif (x[k,0]<=-0):
            y[k,0] = -2 + 0.1*np.log(1-x[k,0]) + err[k,0]
            S[k,0] = 3
            reg3= np.concatenate((reg3, np.array([[y[k,0].item(), x[k,0].item()]])), axis = 0)
     
        
    # Signal-to-noise-ratio 
    P_sig    = (torch.mean((y-err)**2, 0)).item()
    P_noise = std_noise**2
    SNR     = P_sig/(P_noise+1e-10)
    SNR_db  = 10*np.log10(SNR)
    print("Signal-to-noise ratio (dB): %2.2f" % SNR_db)
    
    plt.close('all')
    fig, ax = plt.subplots(3,1,figsize=(5, 5))
    #ax[0].plot(np.array(u), label= 'Input')
    ax[0].plot(np.array(y), label= 'Output')
    ax[1].hist(np.array(S), label = 'Mode sequence')
    ax[2].plot(np.array(x), label = 'Non linearity')
    
    
    
    
    fig, ax = plt.subplots(1,1,figsize=(5, 5))
    ax.scatter(reg1[1:,1], reg1[1:,0],   alpha=0.5)
    ax.scatter(reg2[1:,1], reg2[1:,0],  alpha=0.5)
    ax.scatter(reg3[1:,1], reg3[1:,0],  alpha=0.5)
    
    
    
    # Validation data set Noise free
    xval  = (x_max-x_min)*torch.rand(Nval, n_x) + x_min         # Random input signal training
    yval  = torch.zeros(Nval,1)                # Initial output
    
    Sval  = torch.ones(Nval,1, dtype = int)    # Initial mode sequence

    
    for k in range(0,Nval):
        
        if (xval[k,0]>0 and xval[k,0] <= 10):
            yval[k,0] = -1+ 0.01*xval[k,0]+ 1*(np.sin(xval[k,0]))/xval[k,0]
            Sval[k,0] = 1
        elif (xval[k,0]> 10 and xval[k,0] <= 20):
            yval[k,0] = 2 + 0.2*(np.exp(-0.5*( ((xval[k,0]-15)**2)/5))) 
            Sval[k,0] = 2
        elif (xval[k,0]<=-0):
            yval[k,0] = -2+0.1*np.log(1-xval[k,0]) 
            Sval[k,0] = 3

            
    
    
    
    
    
     ## Prepare data for neural PWA training
    
    phi_torch     = x
    phi_val_torch = xval

    
    #%% K-means for prior probabilites
    #kmeans = KMeans(n_clusters=n_modes, random_state=0).fit(phi_torch)
    gm = GaussianMixture(n_components=n_modes, random_state=0).fit(phi_torch)
    prior_prob = gm.predict_proba(phi_torch)
    
    prior_prob = torch.from_numpy(prior_prob)
    prior_prob = prior_prob.to(torch.float32)

    #%% ------------ Build neural network model -----------------
    
    # Setup VAE model structure
    S_estimator     =  EncoderPWAARX(n_a=1, n_b=n_x-1, n_modes=n_modes, n_feat=n_feat_class)
    #pwa_io_model    =  SwitchIOModel(n_a=n_a, n_b=n_b, n_modes=n_modes, n_feat=n_feat_reg)
    pwa_io_model    =  DecoderPWNL(n_x=n_x, n_modes=n_modes, n_feat=n_feat_reg)
    
    pwa_io_solution =  pwaSimulator(pwa_io_model, S_estimator)
    
    
    
    params_reg   = list(pwa_io_solution.io_model.parameters())
    params_class = list(pwa_io_solution.io_classifier.parameters())
    
    
    
    
    # Setup optimizer
    #optimizer = optim.Adam(pwa_io_solution.io_model.parameters(), lr=lr)
    #optimizer = optim.Adam([{'params': params_reg,    'lr': lr}, {'params': params_class, 'lr': 1*lr}],  lr=lr)
    
    optimizer = optim.Adam(params_reg+params_class, lr = lr)
    
    loss_type = nn.MSELoss()
    
    
    LOSS = []
    start_time = time.time()
    
    #%% -------------Training loop  ------------------------------------ 
    
    for itr in range(1, num_iter+1):
        
        #print('\n Iter: {:04d}'.format(itr))
        optimizer.zero_grad()
        

        
        
        # Perform one-step ahead prediction
        Y_pred, Y_class, S_est = pwa_io_solution.f_onestep_PWA(phi_torch)
        
        
        
    
        
        # Regularization over active mode only 
        
        active_prob = torch.max(Y_class, axis = 1)[0]
        temp = active_prob*torch.log(active_prob)
        reg_loss = torch.mean(temp)
        
        
        
        
        fit_err = (Y_pred-y)**2
        
        
        
        

        
        loss = torch.mean(fit_err) + lam*reg_loss
        
        
        

        
        # Statistics
        LOSS.append(loss.item())
        if itr % test_freq == 0:
            print('Iter {:04d} | Total Loss {:.6f}'.format(itr, loss.item()))
            
            print('Iter {:04d} | Reg Loss {:.6f}'.format(itr, reg_loss.item()))
            

        
        
        
        # Backpropogate and optimize weights
        loss.backward()
        optimizer.step()
        
        #prior_prob = Y_class.detach()
    
    train_time = time.time() - start_time 
    print(f"\nTrain time: {train_time:.2f}")
    
    #%% Results 
    
    with torch.no_grad():
        

        
          y_pred_train, _, S_est_train = pwa_io_solution.f_onestep_PWA(phi_torch)


          
          err_train = y_pred_train - y                # one step ahead error
          loss_train =  torch.mean((err_train)**2)    # ideally  noise variance (0-mean)
          
          
          den = torch.mean((y - torch.mean(y))**2)
          BFR_train_one_step = 100*np.maximum(0, 1 - np.sqrt((loss_train.item())/(den.item())))
          
          R2_train = 100*(1- (loss_train.item())/(den.item()))
          
          # BFR_train_one_step Ideally: 1- (1+10^(SNR_db/10))^(-0.5)
          
          print("---------------------------------------")
          print(f"\n Best Fit Rate Train (one_step): {BFR_train_one_step:2.2f} %")
          
          print("---------------------------------------")
          print(f"\n R2 Train : {R2_train:2.2f} %")
          
          
          ## Test data
          
          y_pred_test, _, S_est_test = pwa_io_solution.f_onestep_PWA(phi_val_torch)
          


          
          err_test = y_pred_test- yval               # one step ahead error
          loss_test =  torch.mean((err_test)**2)    # ideally  noise variance (0-mean)
          
          
          den = torch.mean((yval - torch.mean(yval))**2)
          BFR_test_one_step = 100*np.maximum(0, 1 - np.sqrt((loss_test.item())/(den.item())))
          
          R2_test = 100*(1- (loss_test.item())/(den.item()))
          
          # BFR_train_one_step Ideally: 1- (1+10^(SNR_db/10))^(-0.5)
          
          print("---------------------------------------")
          print(f"\n Best Fit Rate Test (one_step): {BFR_test_one_step:2.2f} %")
          
          print("---------------------------------------")
          print(f"\n R2 Test : {R2_test:2.2f} %")
          
          
          Y_class, S_est = pwa_io_solution.io_classifier(phi_torch) 
          
          Y_class_val, S_est_val = pwa_io_solution.io_classifier(phi_val_torch)
        
        
        
        
        

        
        
        
        
        
        
        
        
    
       
    fig, ax = plt.subplots(1,1, figsize=(5,5))
    ax.plot(LOSS)
    ax.grid(True)
    ax.set_ylabel("Training Loss (-)")
    ax.set_xlabel("Iteration (-)")
    
    fig, ax = plt.subplots(1,1, figsize=(5, 5))
    ax.plot(y_pred_train[0:5000])
    ax.plot(y[0:5000])
    ax.grid(True)
    ax.set_ylabel("Training Output: One step prediction")
    ax.set_xlabel("Samples")
    

    
    
    fig, ax = plt.subplots(1,1, figsize=(5, 5))
    ax.plot(err_train[0:5000])
    ax.plot(err[0:5000])
    ax.grid(True)
    ax.set_ylabel("Error Train ")
    ax.set_xlabel("Samples")
    
    
    fig, ax = plt.subplots(1,1, figsize=(5, 5))
    ax.plot(err_test[0:2000])
    ax.grid(True)
    ax.set_ylabel("Error validation ")
    ax.set_xlabel("Samples")
    
    

    
    
    
    fig, ax = plt.subplots(1,1,figsize=(5, 5))

    #ax.set_xlim(-0.7, 0.7)
    #ax.set_ylim(-1, 1)  
    for j in range(n_modes):
        reg_est_train = phi_torch[(S_est_train==j)[:,0]]
        y_est_train   = y_pred_train[(S_est_train==j)[:,0]]
        ax.scatter(reg_est_train,  y_est_train,  alpha=0.5)

    
    
    
    fig, ax = plt.subplots(1,1,figsize=(5, 5))

    #ax.set_xlim(-0.7, 0.7)
    #ax.set_ylim(-1, 1) 
    for j in range(n_modes):
          reg_est_val = phi_val_torch[(S_est_val==j)[:,0]]
          y_est_val   = y_pred_test[(S_est_val==j)[:,0]]
          ax.scatter(reg_est_val , y_est_val,  alpha=0.5)
          
          xtrue = phi_val_torch[(Sval==j+1)[:,0]]
          xtrue, index = torch.sort(xtrue,0)
          ytrue =  yval[(Sval==j+1)[:,0]]
          ytrue = ytrue[index[:,0],:]
          ax.plot(xtrue, ytrue, 'k--', linewidth=2)

    
    
    #fig, ax = plt.subplots(1,1, figsize=(7.5, 6))
    #ax.plot(S_est[0:200], 'b--')
    #ax.plot(S_init[0:200], 'r--')
    #ax.grid(True)
    #ax.set_ylabel("Mode")
    #ax.set_xlabel("Samples")
        
    #print("----------Weights-------------")
    #print(pwa_io_model.net[0].weight)
    #print(pwa_io_model.net_class[2].weight)
    
    
    
    
    





